<?php

function convertisseur($devise) {
    // traitements/instructions...
    return $devise = 1.085965;
}

// Exécution :
$devise = 1.085965;

echo '1 euro = '.  convertisseur($devise) . ' dollars americains';


?>
